import React, { useState } from "react"
import { Formik, Form, Field } from "formik"//formiks vaimportebt
import "./App.css"

  const memeImages = [
    "/images/meme1.jpg",
    "/images/meme2.jpg",
    "/images/meme3.jpg",
    "/images/meme4.jpg",
    "/images/meme5.jpg", 
  ]
const MemeGenerator = () => {
  const [image, setImage] = useState(memeImages[0])//random fotos shesanaxi state
  const getRandomImage = () => { //randpm fotos asarchevi funqcia
    const randomIndex = Math.floor(Math.random() * memeImages.length)
    setImage(memeImages[randomIndex])
  }

  return (
    <Formik
      initialValues={{
        topText: "Top Text",
        bottomText: "Bottom Text",
        textColor: "#ffffff",
      }}
    >
      {({ values, handleChange }) => (
        <div className="container">
          <Form className="form">
            <label>Top Text:</label>
            <Field type="text" name="topText" onChange={handleChange} />

            <label>Bottom Text:</label>
            <Field type="text" name="bottomText" onChange={handleChange} />

            <label>Text Color:</label>
            <Field type="color" name="textColor" onChange={handleChange} />

            <button type="button" className="random-btn" onClick={getRandomImage}>
              Get a new image
            </button>
          </Form>

          <div className="meme-preview">
            <img src={image} alt="Meme" className="meme-image" />
            <p className="top-text" style={{ color: values.textColor }}>
              {values.topText}
            </p>
            <p className="bottom-text" style={{ color: values.textColor }}>
              {values.bottomText}
            </p>
          </div>
        </div>
      )}
    </Formik>
  )
}

export default MemeGenerator
