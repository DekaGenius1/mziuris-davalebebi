import React, { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import "./styles.css";

//xelmisawvdomi ketilmoyoba
const amenitiesList = ["WiFi", "Parking","Breakfast"];

//validaciis sqema yupis gamoyenebit 
const validationSchema = Yup.object({
  fullName: Yup.string()//input unda iyos stringi
    .min(3, "სახელი უნდა იყოს მინიმუმ 3 ასო")
    .max(20, "სახელი უნდა იყოს მაქსიმუმ 20 ასო")
    .required("სახელი სავალდებულოა"),
  email: Yup.string()//input unda iyos stringi
    .email("Invalid email format")
    .min(4, "Email უნდა იყოს მინიმუმ 3 ასო")
    .max(25, "Email უნდა იყოს მაქსიმუმ 25 ასო")
    .required("Email სავალდებულოა"),
  amenities: Yup.array()//input unda iyos masivi
    .min(1, "მინიმუმ 1 კეთილმოწყობა უნდა იყოს მონიშნული"),
  roomType: Yup.string()//input unda iyos stringi
    .oneOf(["1 კაციანი", "2 კაციანი", "3 კაციანი"],)
    .required("ოთახის ტიპი სავალდებულოა"),
  termsAccepted: Yup.boolean().oneOf([true], "პირობები უნდა გაკმაყოფილებდეთ")//boolean unda iyos monishnuli
})

const FormComponent = () => {
  const [loading, setLoading] = useState(false)//qmnis axal states saxelad loading, false nishnavs rom jer ar aris gashvebuli
  
  const formik = useFormik({
    initialValues: {
      fullName: "",
      email: "",
      amenities: [],
      roomType: "",
      termsAccepted: false
    },
    validationSchema,
    onSubmit: (values) => {
      setLoading(true)//loadingis state gaushva da 1.5 wamis ganvmalobashi ghilaki iblokeba da momxmarebeli vegar achers
      setTimeout(() => {
        console.log(values)//konsolshi gamoaq shevsebuli mnishvnelobebi
        setLoading(false)// ghilaki ixnseba
      }, 1500)
    }
  })

  return (
    <form onSubmit={formik.handleSubmit} className="form-container">
      <div className="form-group">
        <label>Full Name:</label>
        <input type="text" name="fullName" {...formik.getFieldProps("fullName")} className="form-input" />
        {formik.touched.fullName && formik.errors.fullName && <p className="error-text">{formik.errors.fullName}</p>}
      </div>
      
      <div className="form-group">
        <label>Email:</label>
        <input type="email" name="email" {...formik.getFieldProps("email")} className="form-input" />
        {formik.touched.email && formik.errors.email && <p className="error-text">{formik.errors.email}</p>}
      </div>
      
      <div className="form-group">
        <label>Amenities:</label>
        {amenitiesList.map((amenity) => (
          <div key={amenity} className="checkbox-group">
            <input
              type="checkbox"
              name="amenities"
              value={amenity}
              checked={formik.values.amenities.includes(amenity)}
              onChange={formik.handleChange}
            /> {amenity}
          </div>
        ))}
        {formik.touched.amenities && formik.errors.amenities && <p className="error-text">{formik.errors.amenities}</p>}
      </div>
      
      <div className="form-group">
        <label>Room Type:</label>
        <select name="roomType" {...formik.getFieldProps("roomType")} className="form-input">
          <option value="">Select a Room</option>
          <option value="single">1 კაციანი</option>
          <option value="double">2 კაციანი</option>
          <option value="suite">3 კაციანი</option>
        </select>
        {formik.touched.roomType && formik.errors.roomType && <p className="error-text">{formik.errors.roomType}</p>}
      </div>
      
         {/* pirobebis dadastureba */}
      <div className="form-group checkbox-group">
        <input type="checkbox" name="termsAccepted" {...formik.getFieldProps("termsAccepted")} /> ვეთანხმები პირობებს
        {formik.touched.termsAccepted && formik.errors.termsAccepted && <p className="error-text">{formik.errors.termsAccepted}</p>}
      </div>
       {/*im shemtxvevashi, tu itvirteba, anu loading state gashvebulia, daewereba loading... , winaagmdeg shemtxvevashi continue*/}
      <button type="submit" disabled={loading} className="submit-button">
        {loading ? "Loading..." : "Continue"}
      </button>
    </form>
  )
}

export default FormComponent