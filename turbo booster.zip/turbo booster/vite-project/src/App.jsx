import React, { useState } from "react"
import ReactDOM from "react-dom"
import "./styles.css"

function GameSettings() {
  const [username, setUsername] = useState("")
  const [difficulty, setDifficulty] = useState("Medium")
  const [volume, setVolume] = useState(3)
  const [autoSave, setAutoSave] = useState(true)
  const [started, setStarted] = useState(false)
  const lives = { Easy: 5, Medium: 3, Hard: 1 }
  const volumeIcons = ["🔈", "🔉", "🔉", "🔊"]

  const handleStart = () => {
    console.log({ username: username || "Guest", difficulty, volume, autoSave })
    setStarted(true)
  }

  if (started) {
    return <h2 className="text-center text-xl">Joining as {username || "Guest"}...</h2>
  }

  return (
    <div className="container">
      <h2>Game Settings</h2>
      <div className="input-group">
        <label>Username</label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Enter username"
        />
      </div>
      <div className="input-group">
        <label>Difficulty</label>
        <div className="radio-group">
          {["Easy", "Medium", "Hard"].map((level) => (
            <label key={level}>
              <input
                type="radio"
                name="difficulty"
                checked={difficulty === level}
                onChange={() => setDifficulty(level)}
              />
              {level}
            </label>
          ))}
        </div>
      </div>
      <div className="input-group">
        <label>Volume {volumeIcons[volume - 1]}</label>
        <input
          type="range"
          min="1"
          max="4"
          step="1"
          value={volume}
          onChange={(e) => setVolume(Number(e.target.value))}
        />
      </div>
      <div className="input-group checkbox-group">
        <input type="checkbox" checked={autoSave} onChange={() => setAutoSave(!autoSave)} />
        <span>Auto save</span>
      </div>
      {autoSave && <p className="auto-save-text">Saving every 2 minutes</p>}
      <button onClick={handleStart} className="start-btn">START!</button>
      <div className="lives">{lives[difficulty]} 💗</div>
    </div>
  )
}

ReactDOM.render(<GameSettings />, document.getElementById("root"));
